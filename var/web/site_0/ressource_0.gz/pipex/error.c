# include "pipex.h"

void    free_cmds(t_cmd **cmds)
{
    size_t i = -1;

    while (cmds[++i])
        ft_free_elem((void **)&cmds[i]);

    free(cmds);
}

void    exit_prog(t_data *data, const char *cmd, const char *msg, int code, int sys_err)
{
    if (data -> cmds)
        free_cmds(data -> cmds);
    if (data -> path)
        ft_free_tab(data -> path);

    close_fd(&data -> prev_pipes);
    close_fd(&data -> fd[0]);
    close_fd(&data -> fd[1]);
    ft_free_elem((void **)&data -> limiter);
    if (errno == ENOENT && cmd)
        ft_printf("bash:%s : command not found\n", cmd);
    else if (sys_err)
        perror("bash");
    else if (msg)
        ft_printf("%s\n", msg);
    exit(code);
}