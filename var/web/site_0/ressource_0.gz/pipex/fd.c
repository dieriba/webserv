# include "pipex.h"

void    close_fd(int *fd)
{
    if (*fd == -1)
        return ;
    close(*fd);
    *fd = -1;
}