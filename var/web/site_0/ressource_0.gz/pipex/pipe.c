# include "pipex.h"

void    exec_cmd(t_data *data, t_cmd *cmd)
{
    size_t  i = -1;
    
    char **tab = ft_split(cmd -> cmd, ' ');
    char *line;

    if (tab == NULL)
        exit_prog(data, NULL, MALLOC_FAILLED, 1, 0);

    while (data -> path[++i])
    {
        line = ft_strjoin(data -> path[i], "/", tab[0], 1);
        
        if (line == NULL)
            exit_prog(data, NULL, MALLOC_FAILLED, 1, 0);
        
        if (access(line, X_OK | F_OK) == 0)
            break ;
        
        ft_free_elem((void **)&line);
    }
    
    if (line)
        execve(line, tab, data -> envp);

    ft_free_tab(tab);

    exit_prog(data, "bash", NULL, 1, 0);
}

void    forking(t_data *data, t_cmd *cmd, size_t i)
{
    if (i == 0)
    {
        int fd;
        
        if (data -> here_doc == 0)
            fd = open(data -> files[0], O_RDONLY, 0644);
        else
            fd = data -> doc;
            
        if (fd == -1)
            exit_prog(data, NULL, NULL, 1, 1);

        dup2(fd, STDIN_FILENO);
        close_fd(&fd);
        dup2(data -> fd[1], STDOUT_FILENO);
        close_fd(&data -> fd[0]);
        close_fd(&data -> fd[1]);
    }
    else if (i == data -> nb_cmd - 1)
    {
        int flags = OPENFLAG;
        
        if (data -> here_doc)
            flags = HEREODOC_FLAG;

        int fd = open(data -> files[1], flags, 0644);

        if (fd == -1)
            exit_prog(data, NULL, NULL, 1, 1);

        dup2(fd, STDOUT_FILENO);
        close_fd(&fd);
        dup2(data -> prev_pipes, STDIN_FILENO);
        close_fd(&data -> prev_pipes);
    }
    else
    {
        dup2(data -> prev_pipes, STDIN_FILENO);
        dup2(data -> fd[1], STDOUT_FILENO);
        close_fd(&data -> prev_pipes);
        close_fd(&data -> fd[0]);
        close_fd(&data -> fd[1]);
    }

    exec_cmd(data, cmd);
}

void    wait_child(t_data *data, t_cmd **cmd)
{
    size_t  i = -1;
    while (cmd[++i])
        waitpid(cmd[i]->pid, &data -> status, 0);
}

void    lets_pipes(t_data *data)
{
    size_t  i = -1;

    t_cmd **cmds = data -> cmds;

    while (cmds[++i])
    {
        if ((i != data -> nb_cmd - 1) && pipe(data -> fd) == -1)
            exit_prog(data, NULL, PIPE_FAILLED, 1, 0);
        cmds[i]-> pid = fork();
        if (cmds[i]-> pid == -1)
            exit_prog(data, NULL, FORK_FAILLED, 1, 0);
        if (cmds[i]-> pid == 0)
            forking(data, cmds[i], i);
        else
        {
            close_fd(&data -> fd[1]);
            if (data -> doc > 0)
                close_fd(&data -> doc);
            close_fd(&data -> prev_pipes);
            data -> prev_pipes = data -> fd[0];
        }
    }

    wait_child(data, data -> cmds);
}
