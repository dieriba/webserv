# include "pipex.h"

void    set_path(t_data *data)
{
    char    **envp = data -> envp;
    
    if (!envp || !envp[0])
        return ;
    
    size_t i = -1;

    while (envp[++i])
    {
        if (envp[i][0] != 'P')
            continue;
        else
        {
            if (ft_strncmp(envp[i], "PATH=", 5) == 0)
            {
                data -> path = ft_split(&envp[i][5], ':');
                
                if (data -> path == NULL)
                    exit_prog(data, NULL, MALLOC_FAILLED, 1, 0);
            
                break;
            }
        }
    }
}

void    init_cmd(t_data *data, char **argv)
{
    data -> cmds = ft_calloc(sizeof(t_cmd *), data -> nb_cmd + 1);
    
    if (data -> cmds == NULL)
        exit_prog(data, NULL, MALLOC_FAILLED, 1, 0);

    size_t i = -1, j = data -> nb_cmd, k = 2 + data -> here_doc;

    while (++i < j)
    {
        data -> cmds[i] = ft_calloc(sizeof(t_cmd), 1);
        
        if (data -> cmds[i] == NULL)
            exit_prog(data, NULL, MALLOC_FAILLED, 1, 0);

        data -> cmds[i] -> cmd = argv[k++];

        data -> cmds[i] -> data = data;
    }
}

void    init_data(t_data *data, int ac, char **argv, char **envp)
{
    data -> fd[0] = -1;
    data -> fd[1] = -1;
    data -> prev_pipes = -1;
    data -> doc = -1;
    data -> envp = envp;
    data -> files[0] = argv[1];
    data -> files[1] = argv[ac - 1];
    getMyDataBack(data);
    if (ft_strcmp("here_doc", argv[1]) == 0)
    {
        data -> limiter = ft_strjoin(argv[2], "\n", 0 , 0);
        if (data -> limiter == NULL)
            exit_prog(data, NULL, MALLOC_FAILLED, 1, 0);
        data -> here_doc = 1;
        here_doc(data);
    }
    if (data -> here_doc && ac < 6)
        exit_prog(data, NULL, "Usage: ./pipex here_doc limiter cmd1 cmd2 cmd... outfile", 0, 0);
    set_path(data);
    data -> nb_cmd = ac - 3 - data -> here_doc;
}

int main (int argc, char **av, char **envp)
{
    if (argc < 5)
        return (ft_printf("./pipex infile cmd1 cmd2 cmd.. oufile\n") , 0);

    t_data  data;

    signal(SIGINT, clean_project);
    signal(SIGSEGV, clean_project);
    ft_memset(&data, 0, sizeof(data));
    init_data(&data, argc, av, envp);
    init_cmd(&data, av);
    lets_pipes(&data);
    exit_prog(&data, NULL, NULL, 0, 0);
}