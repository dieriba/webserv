# include "pipex.h"

t_data  *getMyDataBack(t_data *data)
{
    static t_data   *_data;

    if (_data == NULL)
        _data = data;
    return _data;
}

void    clean_project(int signal)
{
    (void) signal;
    t_data *data = getMyDataBack(NULL);
    get_next_line(0, 0);
    exit_prog(data, NULL, NULL, 0, 0);
}

void    write_to_doc_pipes(t_data *data)
{
    char *line;

    while (1)
    {
        write(1, "heredoc>: ", 10);
        line = get_next_line(0, 1);
        if (line == NULL || ft_strcmp(line, data -> limiter) == 0)
            break ;
        write(data -> fd[1], line, ft_strlen(line));
        free(line);
    }
    free(line);
    get_next_line(0, 0);
    close_fd(&data -> fd[0]);
    close_fd(&data -> fd[1]);
    exit_prog(data, NULL, NULL, EXIT_SUCCESS, 0);
}

void    here_doc(t_data *data)
{
    pid_t pid;
    
    if (pipe(data -> fd) == -1)
        exit_prog(data, NULL, PIPE_FAILLED, 1, 0);
    
    pid = fork();
    
    if (pid == -1)
        exit_prog(data, NULL, FORK_FAILLED, 1, 0);
    
    if (pid == 0)
        write_to_doc_pipes(data);
    else
    {
        close_fd(&data -> fd[1]);
        signal(SIGINT, SIG_IGN);
        waitpid(pid, &data -> status, 0);
        data -> doc = data -> fd[0];
        if (WIFSIGNALED(data -> status))
        {
            printf("data -> status : %d\n", data -> status);
        }
    }
}