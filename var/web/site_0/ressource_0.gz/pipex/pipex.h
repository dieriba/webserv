# include <unistd.h>
# include <stdlib.h>
# include <sys/types.h>
# include "./libft/libft.h"
# include "./libft/get_next_line/get_next_line.h"
# include "./libft/ft_printf/ft_printf.h"
# include <fcntl.h>
# include <sys/wait.h>
# include <signal.h>
# include <errno.h>
# include <stdio.h>
# define MALLOC_FAILLED "Malloc system call has failed\n"
# define FORK_FAILLED "Fork system call failled\n"
# define PIPE_FAILLED "Pipe system call failled\n"
# define OPEN_SYSTEM_CALL "Open system call failled\n"
# define DUP_SYSTEM_CALL "Dup system call failled\n"

# define HEREODOC_FLAG O_CREAT | O_APPEND | O_RDWR
# define OPENFLAG O_CREAT | O_TRUNC | O_RDWR

typedef struct	s_data	t_data;

typedef struct s_cmd
{
    char	*cmd;
	pid_t	pid;
	t_data	*data;
}   t_cmd;

typedef struct s_data
{
	char	*files[2];
    int		fd[2];
	char	**path;
	int		doc;
	int		here_doc;
	int		prev_pipes;
	size_t		nb_cmd;
	int 	status;
	char	*limiter;
	char	**envp;
	t_cmd	**cmds;
}	t_data;

void    exit_prog(t_data *data, const char *cmd, const char *msg, int code, int sys_err);
void    here_doc(t_data *data);
void    close_fd(int *fd);
void    lets_pipes(t_data *data);
void    clean_project(int signal);

t_data  *getMyDataBack(t_data *data);